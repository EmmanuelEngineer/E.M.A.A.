package it.unisa.emaa.www.sito.Data.entity;

public class StoriaReazioni {

    public void setStoria(Storia storia) {
        this.storia = storia;
    }


    public void setReazionata(boolean reazionata) {
        this.reazionata = reazionata;
    }

    private Storia storia;



    private boolean reazionata;

}
